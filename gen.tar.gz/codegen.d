E:/Project/NFS\ Carbon\ IOS/nfs-carbon-workspace/nfsc-ios/generated/default/codegen.build.stamp: \
  E:/Project/NFS\ Carbon\ IOS/nfs-carbon-workspace/nfsc-ios/game/default.xex \
  E:/Project/NFS\ Carbon\ IOS/nfs-carbon-workspace/nfsc-ios/nfscarbon_manifest.toml
